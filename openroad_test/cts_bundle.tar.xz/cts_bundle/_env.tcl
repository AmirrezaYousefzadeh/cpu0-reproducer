set ::env(CLOCK_NET) clk
set ::env(STEP_ID) OpenROAD.CTS
set ::env(TECH_LEF) ./pdk/sky130A/libs.ref/sky130_fd_sc_hd/techlef/sky130_fd_sc_hd__nom.tlef
set ::env(MACRO_LEFS) ""
set ::env(PDN_CONNECT_MACROS_TO_GRID) 1
set ::env(CTS_ROOT_BUFFER) sky130_fd_sc_hd__clkbuf_16
set ::env(SYNTH_TIEHI_CELL) sky130_fd_sc_hd__conb_1/HI
set ::env(IO_DELAY_CONSTRAINT) 20.0
set ::env(VDD_PIN) VPWR
set ::env(CTS_CLK_MAX_WIRE_LENGTH) 0.0
set ::env(SET_RC_VERBOSE) 0
set ::env(PL_MAX_DISPLACEMENT_Y) 100
set ::env(PL_MAX_DISPLACEMENT_X) 500
set ::env(OUTPUT_CAP_LOAD) 33.442
set ::env(PAD_EDGE_SPACING) 0.0
set ::env(PRIMARY_GDSII_STREAMOUT_TOOL) klayout
set ::env(DEFAULT_CORNER) nom_tt_025C_1v80
set ::env(RT_MIN_LAYER) met1
set ::env(CLOCK_UNCERTAINTY_CONSTRAINT) 0.25
set ::env(STA_CORNERS) "nom_tt_025C_1v80 nom_ss_100C_1v60 nom_ff_n40C_1v95 min_tt_025C_1v80 min_ss_100C_1v60 min_ff_n40C_1v95 max_tt_025C_1v80 max_ss_100C_1v60 max_ff_n40C_1v95"
set ::env(SYNTH_BUFFER_CELL) sky130_fd_sc_hd__buf_2/A/X
set ::env(CTS_DISTANCE_BETWEEN_BUFFERS) 0.0
set ::env(SYNTH_TIELO_CELL) sky130_fd_sc_hd__conb_1/LO
set ::env(FILL_CELLS) "sky130_fd_sc_hd__fill_2 sky130_fd_sc_hd__fill_1"
set ::env(CLOCK_PORT) clk
set ::env(DIODE_CELL) sky130_fd_sc_hd__diode_2/DIODE
set ::env(CTS_SINK_CLUSTERING_ENABLE) 1
set ::env(ENDCAP_CELL) sky130_fd_sc_hd__decap_3
set ::env(MAX_CAPACITANCE_CONSTRAINT) 0.2
set ::env(MAX_TRANSITION_CONSTRAINT) 0.75
set ::env(DESIGN_NAME) snn2_d
set ::env(SCL_GROUND_PINS) "VGND VNB"
set ::env(CELL_LEFS) "./pdk/sky130A/libs.ref/sky130_fd_sc_hd/lef/sky130_fd_sc_hd.lef ./pdk/sky130A/libs.ref/sky130_fd_sc_hd/lef/sky130_ef_sc_hd.lef"
set ::env(SCL_POWER_PINS) "VPWR VPB"
set ::env(CELL_PAD_EXCLUDE) "\"sky130_fd_sc_hd__tap*\" \"sky130_fd_sc_hd__decap*\" \"sky130_ef_sc_hd__decap*\" \"sky130_fd_sc_hd__fill*\""
set ::env(GND_PIN) VGND
set ::env(STD_CELL_LIBRARY) sky130_fd_sc_hd
set ::env(CTS_APPLY_NDR) half
set ::env(RT_MAX_LAYER) met5
set ::env(CLOCK_WIRE_RC_LAYERS) "met3 met4 met5"
set ::env(SYNTH_EXCLUDED_CELL_FILE) ./pdk/sky130A/libs.tech/openlane/sky130_fd_sc_hd/no_synth.cells
set ::env(PNR_EXCLUDED_CELL_FILE) ./pdk/sky130A/libs.tech/openlane/sky130_fd_sc_hd/drc_exclude.cells
set ::env(SYNTH_DRIVING_CELL) sky130_fd_sc_hd__inv_2/Y
set ::env(DEDUPLICATE_CORNERS) 0
set ::env(CTS_DISABLE_POST_PROCESSING) 0
set ::env(DECAP_CELLS) ""
set ::env(TIME_DERATING_CONSTRAINT) 5.0
set ::env(DPL_CELL_PADDING) 0
set ::env(PLACE_SITE) unithd
set ::env(PNR_SDC_FILE) ./core.sdc
set ::env(CLOCK_PERIOD) 10000.0
set ::env(PDN_ENABLE_GLOBAL_CONNECTIONS) 1
set ::env(WELLTAP_CELL) sky130_fd_sc_hd__tapvpwrvgnd_1
set ::env(TECH_LEFS) "\"nom_*\" ./pdk/sky130A/libs.ref/sky130_fd_sc_hd/techlef/sky130_fd_sc_hd__nom.tlef \"min_*\" ./pdk/sky130A/libs.ref/sky130_fd_sc_hd/techlef/sky130_fd_sc_hd__min.tlef \"max_*\" ./pdk/sky130A/libs.ref/sky130_fd_sc_hd/techlef/sky130_fd_sc_hd__max.tlef"
set ::env(PL_OPTIMIZE_MIRRORING) 1
set ::env(MAX_FANOUT_CONSTRAINT) 10
set ::env(CTS_CLK_BUFFERS) "sky130_fd_sc_hd__clkbuf_8 sky130_fd_sc_hd__clkbuf_4 sky130_fd_sc_hd__clkbuf_2"
set ::env(FALLBACK_SDC) ./base.sdc
set ::env(TRISTATE_CELLS) "\"sky130_fd_sc_hd__ebuf*\""
set ::env(CLOCK_TRANSITION_CONSTRAINT) 0.15
set ::env(LIB) "\"*_tt_025C_1v80\" ./pdk/sky130A/libs.ref/sky130_fd_sc_hd/lib/sky130_fd_sc_hd__tt_025C_1v80.lib \"*_ss_100C_1v60\" ./pdk/sky130A/libs.ref/sky130_fd_sc_hd/lib/sky130_fd_sc_hd__ss_100C_1v60.lib \"*_ff_n40C_1v95\" ./pdk/sky130A/libs.ref/sky130_fd_sc_hd/lib/sky130_fd_sc_hd__ff_n40C_1v95.lib"
set ::env(CURRENT_ODB) ./placed.odb
set ::env(SAVE_ODB) ./out/snn2_d.odb
set ::env(SAVE_DEF) ./out/snn2_d.def
set ::env(SAVE_SDC) ./out/snn2_d.sdc
set ::env(SAVE_NL) ./out/snn2_d.nl.v
set ::env(SAVE_PNL) ./out/snn2_d.pnl.v
